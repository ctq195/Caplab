'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { FlaskConical } from 'lucide-react';
import { cn } from '@/lib/utils';

const NAV_ITEMS = [
  { href: '/', label: '开场' },
  { href: '/chat', label: '对话工作台' },
  { href: '/path-convergence', label: '路径收敛' },
  { href: '/evidence-cycle', label: '证据回合' },
  { href: '/resume', label: '简历工坊' },
  { href: '/interview', label: '模拟面试' },
  { href: '/review-report', label: '复盘报告' },
];

export function SiteHeader() {
  const pathname = usePathname();

  return (
    <header className="sticky top-0 z-40 h-16 bg-surface/95 backdrop-blur border-b border-outline-variant/30">
      <div className="max-w-6xl mx-auto h-full px-4 sm:px-6 flex items-center justify-between gap-4">
        <Link href="/" className="flex items-center gap-2.5 shrink-0">
          <span className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <FlaskConical className="w-[18px] h-[18px] text-on-primary" />
          </span>
          <span className="font-bold text-[17px] tracking-tight">CapLab</span>
        </Link>
        <nav
          className="flex items-center gap-0.5 overflow-x-auto scrollbar-none"
          aria-label="主导航"
        >
          {NAV_ITEMS.map((item) => {
            const isActive =
              item.href === '/'
                ? pathname === '/'
                : pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'px-2.5 sm:px-3 py-1.5 text-[13px] font-medium rounded-md transition-colors whitespace-nowrap',
                  isActive
                    ? 'bg-primary/10 text-primary'
                    : 'text-on-surface-variant hover:text-on-surface hover:bg-surface-container'
                )}
                aria-current={isActive ? 'page' : undefined}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
