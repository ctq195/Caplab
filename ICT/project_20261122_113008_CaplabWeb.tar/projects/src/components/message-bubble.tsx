'use client';

import { FlaskConical } from 'lucide-react';
import type { ChatMessage } from '@/lib/chat-types';

export function MessageBubble({ message }: { message: ChatMessage }) {
  if (message.role === 'user') {
    return (
      <div className="flex justify-end">
        <div className="bg-primary text-primary-foreground rounded-2xl rounded-tr-md px-4 py-2.5 max-w-[85%] sm:max-w-[80%] text-sm leading-relaxed whitespace-pre-wrap break-words">
          {message.content}
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start gap-2.5">
      <span className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
        <FlaskConical className="w-4 h-4 text-primary" />
      </span>
      <div className="bg-card shadow-sm rounded-2xl rounded-tl-md px-4 py-3 max-w-[88%] sm:max-w-[82%] text-sm leading-relaxed text-foreground">
        {message.content ? (
          <span className="whitespace-pre-wrap break-words">{message.content}</span>
        ) : message.streaming ? (
          <span className="inline-flex items-center gap-1.5 text-muted-foreground">
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce [animation-delay:-0.3s]" />
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce [animation-delay:-0.15s]" />
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" />
          </span>
        ) : null}
        {message.streaming && message.content && (
          <span className="inline-block w-1.5 h-4 bg-primary ml-0.5 align-text-bottom animate-pulse" />
        )}
      </div>
    </div>
  );
}
