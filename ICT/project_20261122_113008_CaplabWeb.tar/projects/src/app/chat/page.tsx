'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import Link from 'next/link';
import {
  ClipboardList,
  Plus,
  PanelRight,
  Paperclip,
  ArrowUp,
  FileText,
  Image as ImageIcon,
} from 'lucide-react';
import { MessageBubble } from '@/components/message-bubble';
import { StagePanel } from '@/components/stage-panel';
import type { ChatMessage, Attachment } from '@/lib/chat-types';

let idCounter = 0;
const nextId = () => `msg-${Date.now()}-${idCounter++}`;

const WELCOME: ChatMessage = {
  id: 'welcome',
  role: 'assistant',
  content:
    '你好，我是 CapLab 生涯探索助手。在这里你不用立刻给出完美答案——我们会把你现在的困惑，变成几个可以低成本验证的小行动。\n\n你可以直接说说最近在纠结什么，比如“不知道该考研还是找工作”；也可以上传简历或材料。我们先从一个问题开始。',
};

export default function ChatPage() {
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([WELCOME]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [pendingAttachments, setPendingAttachments] = useState<Attachment[]>([]);
  const [error, setError] = useState<string | null>(null);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  // 自动滚动到底部
  const scrollToBottom = useCallback(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  const autoGrow = () => {
    const ta = textareaRef.current;
    if (ta) {
      ta.style.height = 'auto';
      ta.style.height = `${Math.min(ta.scrollHeight, 112)}px`;
    }
  };

  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputValue(e.target.value);
    autoGrow();
  };

  const handleAttachClick = () => fileInputRef.current?.click();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const next: Attachment[] = [];
    Array.from(files).forEach((f) => {
      const sizeKb = f.size / 1024;
      const sizeLabel = sizeKb > 1024 ? `${(sizeKb / 1024).toFixed(1)}MB` : `${Math.round(sizeKb)}KB`;
      next.push({
        name: f.name,
        sizeLabel,
        kind: f.type.startsWith('image/') ? 'image' : 'file',
      });
    });
    setPendingAttachments((prev) => [...prev, ...next]);
    e.target.value = '';
  };

  const removeAttachment = (idx: number) => {
    setPendingAttachments((prev) => prev.filter((_, i) => i !== idx));
  };

  const sendMessage = async (text: string, attachments: Attachment[]) => {
    const content = text.trim();
    if (!content || isStreaming) return;

    setError(null);

    // 用户消息（附带文件信息）
    let userContent = content;
    if (attachments.length > 0) {
      const fileLines = attachments.map((a) => `[已上传${a.kind === 'image' ? '图片' : '文件'}：${a.name}（${a.sizeLabel}）]`);
      userContent = `${content}\n${fileLines.join('\n')}`;
    }
    const userMsg: ChatMessage = { id: nextId(), role: 'user', content: userContent };

    // 占位助手消息
    const assistantId = nextId();
    const assistantMsg: ChatMessage = { id: assistantId, role: 'assistant', content: '', streaming: true };

    const payloadMessages = [...messages, userMsg].map((m) => ({
      role: m.role,
      content: m.content,
    }));

    setMessages((prev) => [...prev, userMsg, assistantMsg]);
    setIsStreaming(true);
    setPendingAttachments([]);
    setInputValue('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: payloadMessages }),
        signal: controller.signal,
      });

      if (!res.ok) {
        const errBody = await res.json().catch(() => null);
        throw new Error(errBody?.error || `请求失败（${res.status}）`);
      }
      if (!res.body) throw new Error('响应没有返回流');

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let accumulated = '';

      const patchAssistant = (updater: (c: string) => string) => {
        setMessages((prev) =>
          prev.map((m) => (m.id === assistantId ? { ...m, content: updater(m.content) } : m)),
        );
      };

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const rawLine of lines) {
          const line = rawLine.trim();
          if (!line.startsWith('data:')) continue;
          const data = line.slice(5).trim();
          if (data === '[DONE]') continue;
          try {
            const json = JSON.parse(data);
            if (json.error) throw new Error(json.error);
            const delta = json.choices?.[0]?.delta?.content;
            if (delta) {
              accumulated += delta;
              const snapshot = accumulated;
              patchAssistant(() => snapshot);
            }
          } catch (parseErr) {
            if (parseErr instanceof Error && parseErr.message && !parseErr.message.includes('JSON')) {
              throw parseErr;
            }
          }
        }
      }

      setMessages((prev) =>
        prev.map((m) => (m.id === assistantId ? { ...m, streaming: false } : m)),
      );
    } catch (e) {
      if ((e as Error).name === 'AbortError') {
        setMessages((prev) =>
          prev.map((m) => (m.id === assistantId ? { ...m, streaming: false } : m)),
        );
      } else {
        const msg = e instanceof Error ? e.message : '发生未知错误';
        setError(msg);
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantId
              ? { ...m, streaming: false, content: m.content || `（生成失败：${msg}）` }
              : m,
          ),
        );
      }
    } finally {
      setIsStreaming(false);
      abortRef.current = null;
    }
  };

  const handleSend = () => {
    void sendMessage(inputValue, pendingAttachments);
  };

  const handleStop = () => {
    abortRef.current?.abort();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleNewChat = () => {
    if (isStreaming) abortRef.current?.abort();
    setMessages([WELCOME]);
    setError(null);
    setPendingAttachments([]);
  };

  const handleExport = () => {
    const data = messages.map((m) => ({ role: m.role, content: m.content }));
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'caplab-export.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDelete = () => {
    if (window.confirm('确定删除本次会话的全部消息吗？此操作不可撤销。')) {
      handleNewChat();
    }
  };

  return (
    <main className="flex flex-col lg:flex-row w-full" style={{ height: 'calc(100vh - 4rem)' }}>
      {/* ========== 中间对话区 ========== */}
      <section className="flex-1 min-w-0 flex flex-col bg-background min-h-0">
        {/* 状态条 */}
        <div className="bg-card/80 border-b border-border/20 px-4 sm:px-5 py-2.5 flex items-center justify-between gap-3 shrink-0">
          <span className="inline-flex items-center gap-1.5 bg-primary/10 text-primary rounded-full px-3 py-1 text-xs font-medium">
            <ClipboardList className="w-3.5 h-3.5" />
            阶段 1/5 · 资料建档
          </span>
          <div className="flex items-center gap-3">
            <span className="hidden sm:inline text-xs text-muted-foreground">
              知识库版本：免费版 v2.3.0
            </span>
            <button
              type="button"
              onClick={handleNewChat}
              className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded-md px-2 py-1 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              新会话
            </button>
            <button
              type="button"
              onClick={() => setIsPanelOpen(!isPanelOpen)}
              className="lg:hidden inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded-md px-2 py-1 transition-colors"
            >
              <PanelRight className="w-4 h-4" />
              阶段与证据
            </button>
          </div>
        </div>

        {/* 气泡流 */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5">
          {messages.map((m) => (
            <MessageBubble key={m.id} message={m} />
          ))}
          {error && (
            <div className="text-xs text-red-600 bg-red-600/10 rounded-lg px-3 py-2">
              {error}
            </div>
          )}
        </div>

        {/* 底部输入区 */}
        <div className="bg-card border-t border-border/20 px-3 sm:px-4 py-3 shrink-0 space-y-2">
          {/* 快捷指令 */}
          <div className="flex items-center gap-2 overflow-x-auto scrollbar-none">
            <button
              type="button"
              onClick={() => textareaRef.current?.focus()}
              className="shrink-0 border border-border/30 rounded-full px-3 py-1 text-xs text-muted-foreground hover:bg-muted transition-colors"
            >
              开始或继续
            </button>
            <Link
              href="/resume"
              className="shrink-0 border border-border/30 rounded-full px-3 py-1 text-xs text-muted-foreground hover:bg-muted transition-colors"
            >
              生成简历
            </Link>
            <Link
              href="/interview"
              className="shrink-0 border border-border/30 rounded-full px-3 py-1 text-xs text-muted-foreground hover:bg-muted transition-colors"
            >
              模拟面试
            </Link>
            <Link
              href="/review-report"
              className="shrink-0 border border-border/30 rounded-full px-3 py-1 text-xs text-muted-foreground hover:bg-muted transition-colors"
            >
              结束并复盘
            </Link>
          </div>

          {/* 待上传附件预览 */}
          {pendingAttachments.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {pendingAttachments.map((a, idx) => (
                <span
                  key={`${a.name}-${idx}`}
                  className="inline-flex items-center gap-1.5 bg-muted rounded-lg px-2.5 py-1.5 text-xs text-foreground"
                >
                  {a.kind === 'image' ? (
                    <ImageIcon className="w-3.5 h-3.5 text-muted-foreground" />
                  ) : (
                    <FileText className="w-3.5 h-3.5 text-muted-foreground" />
                  )}
                  {a.name} · {a.sizeLabel}
                  <button
                    type="button"
                    onClick={() => removeAttachment(idx)}
                    className="text-muted-foreground hover:text-red-600 ml-0.5"
                    aria-label="移除附件"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          )}

          {/* 输入行 */}
          <div className="flex items-end gap-2">
            <button
              type="button"
              aria-label="上传文件"
              onClick={handleAttachClick}
              className="w-10 h-10 shrink-0 rounded-xl text-muted-foreground hover:text-foreground hover:bg-muted flex items-center justify-center transition-colors"
            >
              <Paperclip className="w-5 h-5" />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".pdf,.doc,.docx,.png,.jpg,.jpeg"
              onChange={handleFileChange}
              className="hidden"
            />
            <textarea
              ref={textareaRef}
              rows={1}
              value={inputValue}
              onChange={handleInput}
              onKeyDown={handleKeyDown}
              placeholder="说说你的困惑，或回答上面的问题…"
              className="flex-1 resize-none bg-muted border-none rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30 transition-colors max-h-28"
            />
            {isStreaming ? (
              <button
                type="button"
                aria-label="停止生成"
                onClick={handleStop}
                className="bg-muted text-foreground rounded-xl w-10 h-10 shrink-0 flex items-center justify-center hover:bg-muted-foreground/20 active:scale-95 transition-all"
              >
                <span className="w-3 h-3 bg-foreground rounded-sm" />
              </button>
            ) : (
              <button
                type="button"
                aria-label="发送"
                onClick={handleSend}
                disabled={!inputValue.trim()}
                className="bg-primary text-primary-foreground rounded-xl w-10 h-10 shrink-0 flex items-center justify-center hover:opacity-90 active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <ArrowUp className="w-5 h-5" />
              </button>
            )}
          </div>

          <p className="text-[11px] text-muted-foreground/70 pl-12">
            PDF / Word / 图片 · 内容仅在你确认后写入档案
          </p>
        </div>
      </section>

      {/* 移动端遮罩 */}
      {isPanelOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/40 z-30"
          onClick={() => setIsPanelOpen(false)}
        />
      )}

      {/* 右侧面板 */}
      <aside
        className={`${
          isPanelOpen ? 'flex' : 'hidden'
        } lg:flex w-full lg:w-80 shrink-0 bg-card border-t lg:border-t-0 lg:border-l border-border/20 overflow-y-auto p-4 fixed lg:static inset-y-0 right-0 z-40 lg:z-auto max-w-[340px]`}
      >
        <StagePanel
          currentStage={1}
          pendingCount={3}
          onExport={handleExport}
          onDelete={handleDelete}
        />
      </aside>
    </main>
  );
}
