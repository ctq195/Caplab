'use client';

import Link from 'next/link';
import {
  Compass,
  FlaskConical,
  ArrowRight,
  MessageCircleHeart,
  FileUp,
  BriefcaseBusiness,
  ClipboardList,
  UserCheck,
  GitMerge,
  ClipboardCheck,
  FileUser,
  MessagesSquare,
  BookOpenText,
  ShieldCheck,
} from 'lucide-react';

export default function HomePage() {
  const handleScrollToCapabilities = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const target = document.getElementById('capabilities');
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <main className="max-w-6xl mx-auto px-4 sm:px-6">
      {/* 首屏主视觉区 */}
      <section className="pt-14 sm:pt-20 pb-10 sm:pb-14">
        <div className="max-w-3xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium tracking-wide">
            <Compass className="w-3.5 h-3.5" />
            AI 生涯路径收敛平台 · 面向大学生
          </span>
          <h1 className="mt-5 text-4xl sm:text-5xl font-bold tracking-tight leading-[1.15] text-foreground">
            用现实行动，
            <br className="hidden sm:block" />
            把选择试出来
          </h1>
          <p className="mt-5 text-base sm:text-lg leading-relaxed text-muted-foreground">
            CapLab 不替你做终身决定，而是陪你把不确定的选择拆成低成本的现实行动，用证据收敛方向。
          </p>
          <p className="mt-3 text-sm italic text-muted-foreground/80 font-serif tracking-wide">
            Don't plan the perfect path, prototype it.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link
              href="/chat"
              onClick={() => console.log('开始或继续探索：后续根据本地会话状态决定进入新/旧会话')}
              className="inline-flex items-center gap-2 bg-primary text-primary-foreground rounded-lg px-6 py-3 text-sm font-medium hover:opacity-90 hover:shadow-float active:scale-[0.98] transition-all"
            >
              开始或继续
              <ArrowRight className="w-4 h-4" />
            </Link>
            <a
              id="hero-cta-explore"
              href="#capabilities"
              onClick={handleScrollToCapabilities}
              className="inline-flex items-center gap-2 bg-card text-foreground border border-border/30 rounded-lg px-6 py-3 text-sm font-medium hover:bg-muted active:scale-[0.98] transition-all"
            >
              先看看能做什么
            </a>
          </div>
        </div>
      </section>

      {/* 开场白卡片（AI 助手欢迎语气泡） */}
      <section className="pb-12 sm:pb-16">
        <div className="flex items-start gap-3 sm:gap-4">
          <div className="shrink-0 w-10 h-10 rounded-full bg-primary flex items-center justify-center">
            <FlaskConical className="w-5 h-5 text-primary-foreground" />
          </div>
          <div className="bg-card shadow-card rounded-2xl rounded-tl-md px-5 py-4 max-w-2xl">
            <p className="text-sm sm:text-[15px] leading-relaxed text-foreground">
              你好，我是 CapLab 生涯探索助手。在这里你不用立刻给出完美答案——我们会把你现在的困惑，变成几个可以低成本验证的小行动。你可以从下面任意一种方式开始。
            </p>
          </div>
        </div>
      </section>

      {/* 三个入口卡片 */}
      <section id="capabilities" className="scroll-mt-20 pb-14 sm:pb-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-5">
          {/* 入口卡片1：说一句困惑 */}
          <Link
            id="entry-confusion"
            href="/chat"
            className="group bg-card shadow-card rounded-xl p-5 block hover:shadow-float hover:-translate-y-0.5 transition-all duration-200"
          >
            <span className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10 text-primary">
              <MessageCircleHeart className="w-5 h-5" />
            </span>
            <h2 className="mt-4 text-base font-semibold text-foreground">说一句困惑</h2>
            <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
              哪怕只是"我不知道考研还是找工作"，我们先把决策问题理清楚
            </p>
            <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary">
              开始对话
              <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </span>
          </Link>

          {/* 入口卡片2：上传简历或材料 */}
          <Link
            id="entry-upload"
            href="/chat"
            className="group bg-card shadow-card rounded-xl p-5 block hover:shadow-float hover:-translate-y-0.5 transition-all duration-200"
          >
            <span className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10 text-primary">
              <FileUp className="w-5 h-5" />
            </span>
            <h2 className="mt-4 text-base font-semibold text-foreground">上传简历或材料</h2>
            <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
              支持 PDF / Word / 成绩单与截图，识别结果仅供参考，关键信息由你确认
            </p>
            <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary">
              上传材料
              <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </span>
          </Link>

          {/* 入口卡片3：直接做简历或模拟面试 */}
          <div
            id="entry-direct"
            className="bg-card shadow-card rounded-xl p-5 hover:shadow-float hover:-translate-y-0.5 transition-all duration-200"
          >
            <span className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10 text-primary">
              <BriefcaseBusiness className="w-5 h-5" />
            </span>
            <h2 className="mt-4 text-base font-semibold text-foreground">直接做简历或模拟面试</h2>
            <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
              给出岗位 JD 即可开始，无需先建档；内容逐字段绑定真实来源
            </p>
            <div className="mt-4 flex items-center gap-4">
              <Link
                id="entry-direct-resume"
                href="/resume"
                className="inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline"
              >
                简历工坊
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
              <Link
                id="entry-direct-interview"
                href="/interview"
                className="inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline"
              >
                模拟面试
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 五阶段证据闭环 */}
      <section className="pb-14 sm:pb-20">
        <div className="max-w-2xl">
          <h2 className="text-2xl sm:text-[28px] font-bold tracking-tight text-foreground">五步，把不确定变成证据</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            每一步都以你确认的事实为起点，结论随证据更新，而不是替你下判断。
          </p>
        </div>

        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
          {/* 步骤1：资料建档 */}
          <Link
            id="step-1"
            href="/chat"
            className="relative bg-card shadow-card rounded-xl p-4 block hover:shadow-float hover:-translate-y-0.5 transition-all duration-200"
          >
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-primary/10 text-primary">
                <ClipboardList className="w-4.5 h-4.5" />
              </span>
              <span className="text-2xl font-bold text-muted-foreground/40">1</span>
            </div>
            <h3 className="mt-3 text-sm font-semibold text-foreground">资料建档</h3>
            <p className="mt-1 text-xs leading-relaxed text-muted-foreground">明确这轮要决定什么、期限与硬约束</p>
          </Link>

          {/* 步骤2：画像确认 */}
          <Link
            id="step-2"
            href="/chat"
            className="relative bg-card shadow-card rounded-xl p-4 block hover:shadow-float hover:-translate-y-0.5 transition-all duration-200"
          >
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-primary/10 text-primary">
                <UserCheck className="w-4.5 h-4.5" />
              </span>
              <span className="text-2xl font-bold text-muted-foreground/40">2</span>
            </div>
            <h3 className="mt-3 text-sm font-semibold text-foreground">画像确认</h3>
            <p className="mt-1 text-xs leading-relaxed text-muted-foreground">偏好与能力逐项由你确认，解释都可修改</p>
          </Link>

          {/* 步骤3：路径收敛 */}
          <Link
            id="step-3"
            href="/path-convergence"
            className="relative bg-card shadow-card rounded-xl p-4 block hover:shadow-float hover:-translate-y-0.5 transition-all duration-200"
          >
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-primary/10 text-primary">
                <GitMerge className="w-4.5 h-4.5" />
              </span>
              <span className="text-2xl font-bold text-muted-foreground/40">3</span>
            </div>
            <h3 className="mt-3 text-sm font-semibold text-foreground">路径收敛</h3>
            <p className="mt-1 text-xs leading-relaxed text-muted-foreground">比较门槛、差距、成本与证据缺口</p>
          </Link>

          {/* 步骤4：证据回合 */}
          <Link
            id="step-4"
            href="/evidence-cycle"
            className="relative bg-card shadow-card rounded-xl p-4 block hover:shadow-float hover:-translate-y-0.5 transition-all duration-200"
          >
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-primary/10 text-primary">
                <FlaskConical className="w-4.5 h-4.5" />
              </span>
              <span className="text-2xl font-bold text-muted-foreground/40">4</span>
            </div>
            <h3 className="mt-3 text-sm font-semibold text-foreground">证据回合</h3>
            <p className="mt-1 text-xs leading-relaxed text-muted-foreground">把关键疑问变成低成本现实任务</p>
          </Link>

          {/* 步骤5：证据复盘 */}
          <Link
            id="step-5"
            href="/review-report"
            className="relative bg-card shadow-card rounded-xl p-4 block hover:shadow-float hover:-translate-y-0.5 transition-all duration-200"
          >
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-primary/10 text-primary">
                <ClipboardCheck className="w-4.5 h-4.5" />
              </span>
              <span className="text-2xl font-bold text-muted-foreground/40">5</span>
            </div>
            <h3 className="mt-3 text-sm font-semibold text-foreground">证据复盘</h3>
            <p className="mt-1 text-xs leading-relaxed text-muted-foreground">依据你带回的结果更新判断，不归因懒惰</p>
          </Link>
        </div>
      </section>

      {/* 附加能力条 */}
      <section className="pb-12 sm:pb-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4">
          {/* 附加能力1：简历工坊 */}
          <Link
            id="cap-resume"
            href="/resume"
            className="flex items-start gap-3 bg-card shadow-card rounded-xl px-4 py-3.5 hover:shadow-float transition-all duration-200"
          >
            <span className="shrink-0 inline-flex items-center justify-center w-9 h-9 rounded-lg bg-primary/10 text-primary">
              <FileUser className="w-4.5 h-4.5" />
            </span>
            <span>
              <span className="block text-sm font-semibold text-foreground">简历工坊</span>
              <span className="block mt-0.5 text-xs leading-relaxed text-muted-foreground">
                JD 定制、逐字段来源绑定、拒绝无来源数字
              </span>
            </span>
          </Link>

          {/* 附加能力2：模拟面试 */}
          <Link
            id="cap-interview"
            href="/interview"
            className="flex items-start gap-3 bg-card shadow-card rounded-xl px-4 py-3.5 hover:shadow-float transition-all duration-200"
          >
            <span className="shrink-0 inline-flex items-center justify-center w-9 h-9 rounded-lg bg-primary/10 text-primary">
              <MessagesSquare className="w-4.5 h-4.5" />
            </span>
            <span>
              <span className="block text-sm font-semibold text-foreground">模拟面试</span>
              <span className="block mt-0.5 text-xs leading-relaxed text-muted-foreground">
                连环追问贡献边界，四维反馈
              </span>
            </span>
          </Link>

          {/* 附加能力3：知识库问答 */}
          <Link
            id="cap-knowledge"
            href="/chat"
            className="flex items-start gap-3 bg-card shadow-card rounded-xl px-4 py-3.5 hover:shadow-float transition-all duration-200"
          >
            <span className="shrink-0 inline-flex items-center justify-center w-9 h-9 rounded-lg bg-primary/10 text-primary">
              <BookOpenText className="w-4.5 h-4.5" />
            </span>
            <span>
              <span className="block text-sm font-semibold text-foreground">知识库问答</span>
              <span className="block mt-0.5 text-xs leading-relaxed text-muted-foreground">
                考研 / 考公 / 留学 / 求职实习的规则与时间线，带来源与核验日期
              </span>
            </span>
          </Link>
        </div>
      </section>

      {/* 安全与隐私说明 */}
      <section className="pb-12 border-t border-border/30 pt-6">
        <div className="flex items-start gap-2.5">
          <ShieldCheck className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" />
          <p className="text-xs leading-relaxed text-muted-foreground">
            CapLab 不做心理诊断、不索要身份证号等无关隐私，你可随时导出或删除自己的数据；若你正经历强烈痛苦或即时危险，请优先联系可信任的人、学校心理中心或紧急求助。
          </p>
        </div>
      </section>

      {/* 页脚 */}
      <footer className="pb-10 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="w-6 h-6 rounded-md bg-primary flex items-center justify-center">
            <FlaskConical className="w-3.5 h-3.5 text-primary-foreground" />
          </span>
          <span className="text-sm font-semibold text-foreground">CapLab</span>
          <span className="text-xs text-muted-foreground">Career Action Prototyping Lab</span>
        </div>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
          <span>© 2025 CapLab</span>
          <span className="text-muted-foreground/40">·</span>
          <span>知识库版本：免费版 v2.3.0</span>
        </div>
      </footer>
    </main>
  );
}
