import { NextRequest } from 'next/server';

export const runtime = 'nodejs';

interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

const SYSTEM_PROMPT = `你是 CapLab（Career Action Prototyping Lab）的生涯探索助手，面向中国大学生。

产品理念：不替学生做终身决定，而是用低成本现实行动验证选择（Don't plan the perfect path, prototype it）。

你必须遵守以下对话纪律：
1. 五阶段证据闭环：资料建档 → 画像确认 → 路径收敛 → 证据回合 → 证据复盘。按用户实际进度推进，可跨会话延续，不要求一次走完。
   - 资料建档：只明确本轮决策问题、期限、硬约束，登记专业/年级/院校/入学毕业年份。信息不足时只给"待确认建档草稿"，不评判、不推荐。
   - 画像确认：把从材料得到的偏好/能力/价值观解释与用户原话分开，逐项让用户确认/修改/拒绝；所有解释都是可修正假设。
   - 路径收敛：在每条路径各自要求下比较硬门槛、准备差距、现实成本、证据缺口，输出主路径/复合副路径/暂缓路径/排除路径，以及支持证据、反对证据、未知项、有效期、会改变排序的新证据。
   - 证据回合：把关键不确定问题转成低成本现实任务，任务含五要素：目的、需保留的产物、验收标准、预计时间投入、失败后如何调整。
   - 证据复盘：依据用户带回的结果/产物/未执行原因更新判断；未执行要区分任务过大、现实受阻、失去兴趣、安排冲突，不归因于懒惰。
2. 一次只问一个关键问题，等用户回答再继续，不在首轮抛出完整方案。
3. 三分呈现：已确认事实 / 模型推断（必须明确标注"模型推断"）/ 待核验未知，三者不混淆。
4. 自我理解方法：反思式复述、事件与解释分离、寻找反例、核对言行差异、提供替代解释。禁止"你本质上""你就是在逃避"等确定性心理归因。
5. 不虚构来源、链接、案例或数据。考研、考公/选调、境外升学、求职实习的动态信息（报名/考试/岗位/费用/截止）必须标来源与核验日期，无法确认就标"待核验"。
6. 简历相关：拒绝"500+用户""10万条数据""效率提升X%""独立设计开发"等无来源数字与高强度措辞；用户要求造假时明确拒绝并改用真实信息。
7. 安全：出现自伤/伤人/即时危险表达时，停止生涯话题，温和建议联系可信任的人、学校心理中心或紧急求助，只做危机支持、不做诊断。
8. 用中文回答，语气专业、克制、真诚，不堆术语、不打鸡血。`;

export async function POST(req: NextRequest) {
  let body: { messages?: ChatMessage[]; message?: string };
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: '请求体不是合法 JSON' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  const apiKey = process.env.DEEPSEEK_API_KEY;
  const baseUrl = process.env.DEEPSEEK_BASE_URL || 'https://api.deepseek.com';
  const model = process.env.DEEPSEEK_MODEL || 'deepseek-flash';

  if (!apiKey) {
    return new Response(
      JSON.stringify({
        error: '尚未配置 DEEPSEEK_API_KEY，无法调用模型。请在环境变量中配置后重试。',
      }),
      { status: 503, headers: { 'Content-Type': 'application/json' } },
    );
  }

  // 组装消息：兼容 {messages:[...]} 与 {message:"..."}
  const history: ChatMessage[] = Array.isArray(body.messages)
    ? body.messages.filter((m) => m && typeof m.content === 'string' && m.content.trim())
    : [];
  if (history.length === 0 && body.message) {
    history.push({ role: 'user', content: body.message });
  }
  if (history.length === 0) {
    return new Response(JSON.stringify({ error: 'messages 或 message 不能为空' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  const payload = {
    model,
    messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...history],
    stream: true,
    temperature: 0.7,
  };

  let upstream: Response;
  try {
    upstream = await fetch(`${baseUrl.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify(payload),
    });
  } catch (e) {
    return new Response(
      JSON.stringify({ error: `模型服务请求失败：${e instanceof Error ? e.message : '未知错误'}` }),
      { status: 502, headers: { 'Content-Type': 'application/json' } },
    );
  }

  if (!upstream.ok || !upstream.body) {
    const errText = await upstream.text().catch(() => '');
    return new Response(
      JSON.stringify({ error: `模型服务返回 ${upstream.status}`, detail: errText.slice(0, 500) }),
      { status: upstream.status || 502, headers: { 'Content-Type': 'application/json' } },
    );
  }

  // SSE 透传：把 OpenAI 兼容的 SSE chunk 原样转成 text/event-stream
  const encoder = new TextEncoder();
  const reader = upstream.body.getReader();

  const stream = new ReadableStream({
    async start(controller) {
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          controller.enqueue(value);
        }
      } catch (e) {
        controller.enqueue(
          encoder.encode(
            `data: ${JSON.stringify({ error: e instanceof Error ? e.message : '流中断' })}\n\n`,
          ),
        );
      } finally {
        controller.enqueue(encoder.encode('data: [DONE]\n\n'));
        controller.close();
      }
    },
    cancel() {
      reader.cancel().catch(() => {});
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    },
  });
}

export async function GET() {
  return new Response(
    JSON.stringify({
      name: 'CapLab 对话 API',
      version: '2.0.0-streaming',
      model: process.env.DEEPSEEK_MODEL || 'deepseek-flash',
      configured: Boolean(process.env.DEEPSEEK_API_KEY),
    }),
    { status: 200, headers: { 'Content-Type': 'application/json' } },
  );
}
