'use client';

import React, { useState } from 'react';
import {
  FlaskConical,
  FileUser,
  ShieldX,
  Ban,
  ChevronDown,
  Table2,
  CheckCircle2,
  ScanSearch,
  Info,
  HelpCircle,
  Gauge,
  ListChecks,
  CornerDownRight,
  ZoomOut,
  ZoomIn,
  FileDown,
  FileCode2,
  Printer,
  GraduationCap,
  Layers,
  XCircle,
  Wrench,
  Clock,
  UserCheck,
  Download,
  FolderPlus,
  Check,
  ArrowRight,
  ArrowLeft,
  AlertTriangle,
  Paperclip,
} from 'lucide-react';

export default function ResumePage() {
  const [showBannedExamples, setShowBannedExamples] = useState(false);
  const [zoom, setZoom] = useState(100);
  const [saveStatusVisible, setSaveStatusVisible] = useState(false);

  const handleZoomOut = () => {
    if (zoom > 80) setZoom(zoom - 10);
  };

  const handleZoomIn = () => {
    if (zoom < 120) setZoom(zoom + 10);
  };

  const handleParseJD = () => {
    console.log('拆解 JD：当前为静态演示，识别结果已预填（职责4/必备2/加分1）');
  };

  const handleDownloadPDF = () => {
    console.log('下载 PDF：原型占位，正式版按一页 A4 导出（可选择是否保留来源角标）');
  };

  const handleDownloadSource = () => {
    console.log('下载可编辑源文件：原型占位，正式版导出可编辑文档及来源绑定结构');
  };

  const handlePrint = () => {
    console.log('打印：原型占位，正式版调用 window.print() 并套用 A4 打印样式');
  };

  const handleSaveMaterials = () => {
    setSaveStatusVisible(true);
    console.log('已保存当前简历版本到「我的材料」');
  };

  return (
    <main className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
      {/* 左右分栏：左侧编辑/材料区，右侧 A4 实时预览 */}
      <div className="flex flex-col lg:flex-row gap-6">
        {/* ============ 左侧：编辑 / 材料区 ============ */}
        <div className="flex-1 min-w-0 space-y-5 order-2 lg:order-1">
          {/* 页头 */}
          <section>
            <span className="inline-flex items-center gap-1.5 bg-[#D9ECE7] text-[#0E6A5F] rounded-full px-3 py-1 text-xs font-medium">
              <FileUser className="w-3.5 h-3.5" />
              附加能力 · 简历工坊
            </span>
            <h1 className="text-2xl font-bold mt-2.5 tracking-tight">逐字段可溯源的岗位简历</h1>
            <p className="text-sm text-[#59635E] mt-1">
              没有 JD 时生成通用岗位方向版；所有数字与成果必须来自你的材料或你本人确认。
            </p>
          </section>

          {/* 反造假纪律提示条 */}
          <section id="anti-fraud-bar" className="bg-[#C83E33]/5 border border-[#C83E33]/20 rounded-lg p-3">
            <div className="flex items-start gap-2.5">
              <ShieldX className="w-4 h-4 text-[#C83E33] shrink-0 mt-0.5" />
              <p className="text-[13px] leading-relaxed text-[#1C2321] flex-1">
                我不会写入无来源的数字或高强度措辞——例如"500+用户""10万条数据""效率提升X%""独立设计开发"。如果你需要虚构内容，我会明确拒绝，并帮你把真实经历写得更清楚。
              </p>
              <button
                id="btn-toggle-banned"
                onClick={() => setShowBannedExamples(!showBannedExamples)}
                className="shrink-0 inline-flex items-center gap-1 text-xs font-medium text-[#C83E33] hover:underline"
              >
                <Ban className="w-3.5 h-3.5" />
                查看禁用表达示例
                <ChevronDown className={`w-3 h-3 transition-transform ${showBannedExamples ? 'rotate-180' : ''}`} />
              </button>
            </div>
            {/* 禁用表达示例 */}
            {showBannedExamples && (
              <div id="banned-examples" className="mt-3 pl-6 border-t border-[#C83E33]/15 pt-3">
                <p className="text-xs font-semibold text-[#59635E] mb-2">以下表达均无材料来源，已被本版简历拒绝：</p>
                <div className="flex flex-wrap gap-2">
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-xs bg-[#C83E33]/10 text-[#C83E33] line-through">
                    500+用户
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-xs bg-[#C83E33]/10 text-[#C83E33] line-through">
                    10万条数据
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-xs bg-[#C83E33]/10 text-[#C83E33] line-through">
                    效率提升40%
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-xs bg-[#C83E33]/10 text-[#C83E33] line-through">
                    独立设计开发
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-xs bg-[#C83E33]/10 text-[#C83E33] line-through">
                    精通 / 熟练掌握
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-xs bg-[#C83E33]/10 text-[#C83E33] line-through">
                    主导 / 全权负责
                  </span>
                </div>
                <p className="text-xs text-[#59635E] mt-2">
                  如需表达能力强度，请改为"基础 / 参与 / 协助"，或提供可核验材料后由你本人确认升级。
                </p>
              </div>
            )}
          </section>

          {/* JD 输入卡 */}
          <section className="bg-white shadow-[0_1px_3px_rgba(28,35,33,0.07),_0_1px_2px_rgba(28,35,33,0.05)] rounded-lg p-4">
            <label htmlFor="jd-textarea" className="block text-sm font-semibold mb-1.5">
              目标岗位 JD（粘贴岗位职责与要求）
            </label>
            <textarea
              id="jd-textarea"
              className="w-full bg-[#EFEEE9] border-none rounded-lg p-3 text-sm text-[#1C2321] min-h-[110px] resize-y focus:outline-none focus:ring-2 focus:ring-[#0E6A5F]/30 transition-colors"
              placeholder="粘贴岗位职责与任职要求；留空则生成通用岗位方向版"
              defaultValue="AI 产品经理实习生｜协助产品经理进行用户需求收集与梳理；参与产品功能原型设计；跟踪上线数据并整理分析报告；要求：沟通清晰、对 AI 产品有热情、有产品/项目经历优先。"
            />
            <div className="flex flex-wrap items-center gap-2 mt-3">
              {/* 芯片-识别结果 */}
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs bg-[#0E6A5F]/10 text-[#0E6A5F]">
                <CheckCircle2 className="w-3.5 h-3.5" />
                已识别：职责 4 项 / 必备 2 项 / 加分 1 项
              </span>
              <button
                id="btn-parse-jd"
                onClick={handleParseJD}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium text-[#1C2321] border border-[#D9D7D0]/30 hover:bg-[#EFEEE9] transition-colors"
              >
                <ScanSearch className="w-3.5 h-3.5" />
                拆解 JD
              </button>
              <span className="text-xs text-[#59635E] inline-flex items-center gap-1 ml-auto">
                <Info className="w-3.5 h-3.5" />
                没有 JD？当前为：AI 产品实习方向版
              </span>
            </div>
          </section>

          {/* 证据矩阵卡 */}
          <section className="bg-white shadow-[0_1px_3px_rgba(28,35,33,0.07),_0_1px_2px_rgba(28,35,33,0.05)] rounded-lg p-4">
            <h2 className="text-base font-semibold flex items-center gap-2">
              <Table2 className="w-4 h-4 text-[#0E6A5F]" />
              经历证据矩阵（决定每条经历怎么写）
            </h2>
            <div className="mt-3 border border-[#D9D7D0]/20 rounded-lg overflow-hidden">
              {/* 表头 */}
              <div className="grid grid-cols-12 px-3 py-2.5 bg-[#EFEEE9] text-xs font-semibold text-[#59635E]">
                <span className="col-span-5">经历</span>
                <span className="col-span-3">证据等级</span>
                <span className="col-span-4">可写法</span>
              </div>
              <div className="divide-y divide-[#D9D7D0]/20">
                {/* 矩阵行1：二手书小程序-需求整理 */}
                <div className="grid grid-cols-12 px-3 py-2.5 items-center">
                  <span className="col-span-5 text-sm text-[#1C2321]">二手书小程序-需求整理</span>
                  <span className="col-span-3">
                    <span className="inline-flex items-center px-2 py-0.5 rounded-sm text-xs font-medium bg-[#1E8E5A]/15 text-[#1E8E5A]">
                      direct
                    </span>
                  </span>
                  <span className="col-span-4 text-xs text-[#59635E] leading-relaxed">
                    "动作+方法+对象+结果"可直接写，须注明团队协作
                  </span>
                </div>
                {/* 矩阵行2：校友访谈纪要 */}
                <div className="grid grid-cols-12 px-3 py-2.5 items-center">
                  <span className="col-span-5 text-sm text-[#1C2321]">校友访谈纪要</span>
                  <span className="col-span-3">
                    <span className="inline-flex items-center px-2 py-0.5 rounded-sm text-xs font-medium bg-[#1E8E5A]/15 text-[#1E8E5A]">
                      direct
                    </span>
                  </span>
                  <span className="col-span-4 text-xs text-[#59635E] leading-relaxed">可写访谈与纪要产出</span>
                </div>
                {/* 矩阵行3：Figma/Axure 原型 */}
                <div className="grid grid-cols-12 px-3 py-2.5 items-center">
                  <span className="col-span-5 text-sm text-[#1C2321]">Figma/Axure 原型</span>
                  <span className="col-span-3">
                    <span className="inline-flex items-center px-2 py-0.5 rounded-sm text-xs font-medium bg-[#0E6A5F]/15 text-[#0E6A5F]">
                      supportable
                    </span>
                  </span>
                  <span className="col-span-4 text-xs text-[#59635E] leading-relaxed">
                    写"参与部分页面原型"，不写"独立设计"
                  </span>
                </div>
                {/* 矩阵行4：SQL/Python */}
                <div className="grid grid-cols-12 px-3 py-2.5 items-center">
                  <span className="col-span-5 text-sm text-[#1C2321]">SQL/Python</span>
                  <span className="col-span-3">
                    <span className="inline-flex items-center px-2 py-0.5 rounded-sm text-xs font-medium bg-[#E7E6E0] text-[#59635E]">
                      transferable
                    </span>
                  </span>
                  <span className="col-span-4 text-xs text-[#59635E] leading-relaxed">
                    课程水平，写"基础"，不写"熟练/精通"
                  </span>
                </div>
                {/* 矩阵行5：Titanic */}
                <div className="grid grid-cols-12 px-3 py-2.5 items-center">
                  <span className="col-span-5 text-sm text-[#1C2321]">Kaggle Titanic</span>
                  <span className="col-span-3">
                    <span className="inline-flex items-center px-2 py-0.5 rounded-sm text-xs font-medium bg-[#E7E6E0] text-[#59635E]">
                      not_relevant / gap
                    </span>
                  </span>
                  <span className="col-span-4 text-xs text-[#59635E] leading-relaxed">
                    教程跟做，不作为独立项目；可在备注不列
                  </span>
                </div>
                {/* 矩阵行6：量化成果 */}
                <div className="grid grid-cols-12 px-3 py-2.5 items-center">
                  <span className="col-span-5 text-sm text-[#1C2321]">量化成果（用户数/提升%）</span>
                  <span className="col-span-3">
                    <span className="inline-flex items-center px-2 py-0.5 rounded-sm text-xs font-medium bg-[#B57A0A]/15 text-[#B57A0A]">
                      gap
                    </span>
                  </span>
                  <span className="col-span-4 text-xs text-[#59635E] leading-relaxed">
                    待你确认：有可核验数字再写，否则用定性结果
                  </span>
                </div>
              </div>
            </div>
            <p className="text-xs text-[#59635E] mt-2 flex items-start gap-1">
              <HelpCircle className="w-3.5 h-3.5 shrink-0 mt-px" />
              direct＝直接经历；supportable＝可被材料支持；transferable＝可迁移未验证；gap＝缺口；not_relevant＝不相关。
            </p>
          </section>

          {/* 评分与修改建议卡 */}
          <section className="bg-white shadow-[0_1px_3px_rgba(28,35,33,0.07),_0_1px_2px_rgba(28,35,33,0.05)] rounded-lg p-4">
            <h2 className="text-base font-semibold flex items-center gap-2">
              <Gauge className="w-4 h-4 text-[#0E6A5F]" />
              简历评分
            </h2>
            <p className="text-xs text-[#59635E] mt-1">用于内部优化，非 ATS 官方评分、非录用概率。总分仅作改进优先级参考。</p>

            <div className="flex items-end gap-3 mt-3 mb-4">
              <span className="text-3xl font-bold text-[#0E6A5F] leading-none">86</span>
              <span className="text-sm text-[#59635E] mb-0.5">/ 100（优化参考分，逐维度解读见下）</span>
            </div>

            {/* 维度1：岗位覆盖 */}
            <div className="mb-2.5">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-medium text-[#1C2321]">岗位覆盖</span>
                <span className="text-xs text-[#59635E]">90</span>
              </div>
              <div className="h-1.5 bg-[#EFEEE9] rounded-full overflow-hidden">
                <div className="h-full bg-[#0E6A5F] rounded-full" style={{ width: '90%' }}></div>
              </div>
            </div>
            {/* 维度2：证据强度 */}
            <div className="mb-2.5">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-medium text-[#1C2321]">证据强度</span>
                <span className="text-xs text-[#59635E]">88</span>
              </div>
              <div className="h-1.5 bg-[#EFEEE9] rounded-full overflow-hidden">
                <div className="h-full bg-[#0E6A5F] rounded-full" style={{ width: '88%' }}></div>
              </div>
            </div>
            {/* 维度3：技术关键性 */}
            <div className="mb-2.5">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-medium text-[#1C2321]">技术关键性</span>
                <span className="text-xs text-[#59635E]">80</span>
              </div>
              <div className="h-1.5 bg-[#EFEEE9] rounded-full overflow-hidden">
                <div className="h-full bg-[#0E6A5F] rounded-full" style={{ width: '80%' }}></div>
              </div>
            </div>
            {/* 维度4：量化成果（真实） */}
            <div className="mb-2.5">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-medium text-[#1C2321] flex items-center gap-1">
                  量化成果（真实）
                  <span className="inline-flex items-center px-1.5 py-px rounded-sm text-[10px] bg-[#B57A0A]/10 text-[#B57A0A]">
                    未造假
                  </span>
                </span>
                <span className="text-xs text-[#59635E]">72</span>
              </div>
              <div className="h-1.5 bg-[#EFEEE9] rounded-full overflow-hidden">
                <div className="h-full bg-[#B57A0A] rounded-full" style={{ width: '72%' }}></div>
              </div>
              <p className="text-[11px] text-[#59635E] mt-1">无可核验数字，用定性结果，未因缺数字而鼓励造假。</p>
            </div>
            {/* 维度5：个人贡献边界 */}
            <div className="mb-2.5">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-medium text-[#1C2321]">个人贡献边界</span>
                <span className="text-xs text-[#59635E]">92</span>
              </div>
              <div className="h-1.5 bg-[#EFEEE9] rounded-full overflow-hidden">
                <div className="h-full bg-[#0E6A5F] rounded-full" style={{ width: '92%' }}></div>
              </div>
            </div>
            {/* 维度6：认可度 */}
            <div className="mb-2.5">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-medium text-[#1C2321]">认可度</span>
                <span className="text-xs text-[#59635E]">82</span>
              </div>
              <div className="h-1.5 bg-[#EFEEE9] rounded-full overflow-hidden">
                <div className="h-full bg-[#0E6A5F] rounded-full" style={{ width: '82%' }}></div>
              </div>
            </div>
            {/* 维度7：时效性 */}
            <div className="mb-2.5">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-medium text-[#1C2321]">时效性</span>
                <span className="text-xs text-[#59635E]">90</span>
              </div>
              <div className="h-1.5 bg-[#EFEEE9] rounded-full overflow-hidden">
                <div className="h-full bg-[#0E6A5F] rounded-full" style={{ width: '90%' }}></div>
              </div>
            </div>
            {/* 维度8：版面信息量 */}
            <div className="mb-1">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-medium text-[#1C2321]">版面信息量</span>
                <span className="text-xs text-[#59635E]">85</span>
              </div>
              <div className="h-1.5 bg-[#EFEEE9] rounded-full overflow-hidden">
                <div className="h-full bg-[#0E6A5F] rounded-full" style={{ width: '85%' }}></div>
              </div>
            </div>

            {/* 修改建议 */}
            <div className="mt-4 pt-3 border-t border-[#D9D7D0]/20">
              <h3 className="text-sm font-semibold mb-2 flex items-center gap-1.5">
                <ListChecks className="w-4 h-4 text-[#0E6A5F]" />
                修改建议（真实可执行）
              </h3>
              <ul className="space-y-2">
                {/* 建议1 */}
                <li className="flex items-start gap-2 text-[13px] text-[#1C2321] leading-relaxed">
                  <CornerDownRight className="w-3.5 h-3.5 text-[#59635E] shrink-0 mt-1" />
                  把"参与开发"统一改为具体负责的需求与原型范围，避免被误读为独立开发。
                </li>
                {/* 建议2 */}
                <li className="flex items-start gap-2 text-[13px] text-[#1C2321] leading-relaxed">
                  <CornerDownRight className="w-3.5 h-3.5 text-[#59635E] shrink-0 mt-1" />
                  补一个可核验结果：如访谈后哪几条需求进入了原型（你确认后可写）。
                </li>
                {/* 建议3 */}
                <li className="flex items-start gap-2 text-[13px] text-[#1C2321] leading-relaxed">
                  <CornerDownRight className="w-3.5 h-3.5 text-[#59635E] shrink-0 mt-1" />
                  Titanic 教程跟做建议不列，或明确标注"课程练习"。
                </li>
                {/* 建议4 */}
                <li className="flex items-start gap-2 text-[13px] text-[#1C2321] leading-relaxed">
                  <CornerDownRight className="w-3.5 h-3.5 text-[#59635E] shrink-0 mt-1" />
                  联系方式为占位，请替换为真实信息。
                </li>
              </ul>
            </div>
          </section>
        </div>

        {/* ============ 右侧：A4 简历实时预览 ============ */}
        <div className="w-full lg:w-[640px] shrink-0 order-1 lg:order-2">
          <div className="lg:sticky lg:top-20">
            {/* 预览工具条 */}
            <div className="flex items-center gap-1.5 mb-3 bg-white shadow-[0_1px_3px_rgba(28,35,33,0.07),_0_1px_2px_rgba(28,35,33,0.05)] rounded-lg p-2">
              <button
                id="btn-zoom-out"
                onClick={handleZoomOut}
                className="p-1.5 rounded-md text-[#59635E] hover:bg-[#EFEEE9] hover:text-[#1C2321] transition-colors"
                title="缩小"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span id="zoom-label" className="text-xs text-[#59635E] min-w-[44px] text-center">
                {zoom}%
              </span>
              <button
                id="btn-zoom-in"
                onClick={handleZoomIn}
                className="p-1.5 rounded-md text-[#59635E] hover:bg-[#EFEEE9] hover:text-[#1C2321] transition-colors"
                title="放大"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <span className="w-px h-4 bg-[#D9D7D0]/40 mx-1"></span>
              <button
                id="btn-download-pdf-top"
                onClick={handleDownloadPDF}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-medium text-[#1C2321] border border-[#D9D7D0]/30 hover:bg-[#EFEEE9] transition-colors"
              >
                <FileDown className="w-3.5 h-3.5" />
                下载 PDF
              </button>
              <button
                id="btn-download-source-top"
                onClick={handleDownloadSource}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-medium text-[#1C2321] border border-[#D9D7D0]/30 hover:bg-[#EFEEE9] transition-colors"
              >
                <FileCode2 className="w-3.5 h-3.5" />
                可编辑源
              </button>
              <button
                id="btn-print-top"
                onClick={handlePrint}
                className="p-1.5 rounded-md text-[#59635E] hover:bg-[#EFEEE9] hover:text-[#1C2321] transition-colors ml-auto"
                title="打印"
              >
                <Printer className="w-4 h-4" />
              </button>
            </div>

            {/* A4 纸面（真实一页简历内容） */}
            <div
              id="resume-paper-scaler"
              className="origin-top"
              style={{ transform: `scale(${zoom / 100})` }}
            >
              <div
                className="bg-white shadow-[0_8px_24px_rgba(28,35,33,0.10),_0_2px_6px_rgba(28,35,33,0.05)] rounded-md p-7 text-[#1C2321]"
                style={{ aspectRatio: '210 / 297' }}
              >
                <div className="h-full flex flex-col">
                  {/* 姓名与求职意向 */}
                  <header className="border-b border-[#D9D7D0] pb-2.5">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h2 className="text-xl font-bold leading-tight">林同学</h2>
                        <p className="text-[13px] text-[#59635E] mt-0.5">求职意向：AI 产品经理实习生（本地）</p>
                      </div>
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-[11px] bg-[#B57A0A]/10 text-[#B57A0A] shrink-0">
                        <AlertTriangle className="w-3 h-3" />
                        一页版 · A4
                      </span>
                    </div>
                    {/* 占位联系方式 */}
                    <div className="flex flex-wrap items-center gap-1.5 mt-2">
                      <span className="text-[11px] text-[#59635E]">
                        手机：138****0000（示例占位）｜邮箱：lin@example（示例占位）
                      </span>
                      <span className="inline-flex items-center gap-1 px-1.5 py-px rounded-sm text-[10px] bg-[#C83E33]/10 text-[#C83E33]">
                        <Wrench className="w-2.5 h-2.5" />
                        占位信息，请替换
                      </span>
                    </div>
                  </header>

                  {/* 教育背景 */}
                  <section className="mt-3">
                    <h3 className="text-[13px] font-bold text-[#0E6A5F] flex items-center gap-1.5 mb-1.5">
                      <GraduationCap className="w-3.5 h-3.5" />
                      教育背景
                    </h3>
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-[12px] leading-relaxed">某 211 院校 · 计算机科学与技术 · 本科</p>
                      <span className="text-[11px] text-[#59635E] shrink-0">2023.09–2027.06</span>
                    </div>
                    <span className="inline-flex items-center gap-1 mt-0.5 text-[10px] text-[#59635E] bg-[#EFEEE9] px-1.5 py-px rounded-sm">
                      <Paperclip className="w-2.5 h-2.5" />
                      来源：简历.pdf
                    </span>
                  </section>

                  {/* 项目经历 */}
                  <section className="mt-3 flex-1">
                    <h3 className="text-[13px] font-bold text-[#0E6A5F] flex items-center gap-1.5 mb-1.5">
                      <Layers className="w-3.5 h-3.5" />
                      项目经历
                    </h3>

                    {/* 经历1：二手书小程序 */}
                    <div className="mb-2.5">
                      <div className="flex items-baseline justify-between gap-2">
                        <p className="text-[12px] font-semibold">二手书小程序（4 人团队）｜需求与原型</p>
                        <span className="text-[10px] text-[#59635E] shrink-0">校园项目</span>
                      </div>
                      <ul className="mt-1 space-y-1">
                        <li className="flex items-start gap-1.5 text-[11.5px] leading-relaxed">
                          <span className="w-1 h-1 rounded-full bg-[#0E6A5F] shrink-0 mt-[7px]"></span>
                          <span className="flex-1">
                            访谈 12 位同学整理需求清单，完成部分页面原型；与两位学长协作推进开发与发布（团队协作，后端非本人完成）。
                          </span>
                          <span className="inline-flex items-center gap-0.5 text-[9.5px] text-[#59635E] bg-[#EFEEE9] px-1 py-px rounded-sm shrink-0 mt-px">
                            <Paperclip className="w-2.5 h-2.5" />
                            简历.pdf
                          </span>
                        </li>
                      </ul>
                      {/* 被拒绝的写法对照 */}
                      <div className="mt-1.5 space-y-1">
                        <div className="flex items-start gap-1.5 bg-[#C83E33]/5 border border-[#C83E33]/15 rounded px-2 py-1">
                          <XCircle className="w-3 h-3 text-[#C83E33] shrink-0 mt-px" />
                          <span className="text-[10.5px] text-[#59635E] line-through flex-1">
                            独立设计开发小程序，服务 500+ 用户，效率提升 40%
                          </span>
                          <span className="inline-flex items-center text-[9.5px] text-[#C83E33] shrink-0">
                            无来源，已拒绝
                          </span>
                        </div>
                        <div className="flex items-start gap-1.5 bg-[#1E8E5A]/5 border border-[#1E8E5A]/15 rounded px-2 py-1">
                          <CheckCircle2 className="w-3 h-3 text-[#1E8E5A] shrink-0 mt-px" />
                          <span className="text-[10.5px] text-[#1C2321] flex-1">
                            在团队中负责需求整理与部分原型（真实可核验）
                          </span>
                          <span className="inline-flex items-center gap-0.5 text-[9.5px] text-[#1E8E5A] shrink-0">
                            <UserCheck className="w-2.5 h-2.5" />
                            用户确认
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* 经历2：院系职业分享 */}
                    <div>
                      <div className="flex items-baseline justify-between gap-2">
                        <p className="text-[12px] font-semibold">院系职业分享｜志愿者</p>
                        <span className="text-[10px] text-[#59635E] shrink-0">校园活动</span>
                      </div>
                      <ul className="mt-1 space-y-1">
                        <li className="flex items-start gap-1.5 text-[11.5px] leading-relaxed">
                          <span className="w-1 h-1 rounded-full bg-[#0E6A5F] shrink-0 mt-[7px]"></span>
                          <span className="flex-1">现场访谈 2 位校友产品经理，整理访谈纪要并用于现场问答。</span>
                          <span className="inline-flex items-center gap-0.5 text-[9.5px] text-[#59635E] bg-[#EFEEE9] px-1 py-px rounded-sm shrink-0 mt-px">
                            <Paperclip className="w-2.5 h-2.5" />
                            用户确认
                          </span>
                        </li>
                      </ul>
                    </div>
                  </section>

                  {/* 技能 */}
                  <section className="mt-3">
                    <h3 className="text-[13px] font-bold text-[#0E6A5F] flex items-center gap-1.5 mb-1.5">
                      <Wrench className="w-3.5 h-3.5" />
                      技能
                    </h3>
                    <ul className="space-y-0.5">
                      <li className="flex items-start gap-1.5 text-[11.5px] leading-relaxed">
                        <span className="w-1 h-1 rounded-full bg-[#0E6A5F] shrink-0 mt-[7px]"></span>
                        <span>SQL 基础、Python（课程水平）、Axure/Figma 入门</span>
                      </li>
                      <li className="flex items-start gap-1.5 text-[11.5px] leading-relaxed">
                        <span className="w-1 h-1 rounded-full bg-[#0E6A5F] shrink-0 mt-[7px]"></span>
                        <span className="flex-1">英语 CET-4</span>
                        <span className="inline-flex items-center gap-0.5 text-[9.5px] text-[#B57A0A] bg-[#B57A0A]/10 px-1 py-px rounded-sm shrink-0">
                          <Clock className="w-2.5 h-2.5" />
                          成绩单截图，待确认
                        </span>
                      </li>
                    </ul>
                    <p className="text-[10px] text-[#59635E] mt-1">
                      说明：技能等级均按真实课程 / 入门水平标注，未使用"精通 / 熟练"。
                    </p>
                  </section>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 底部操作条 */}
      <section id="bottom-action-bar" className="mt-8 bg-white shadow-[0_8px_24px_rgba(28,35,33,0.10),_0_2px_6px_rgba(28,35,33,0.05)] rounded-lg p-4">
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            id="btn-download-pdf"
            onClick={handleDownloadPDF}
            className="inline-flex items-center gap-2 bg-[#0E6A5F] text-white px-4 py-2 rounded-md text-sm font-medium hover:opacity-90 active:scale-[0.98] transition-all"
          >
            <Download className="w-4 h-4" />
            下载 PDF
          </button>
          <button
            id="btn-download-source"
            onClick={handleDownloadSource}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium text-[#1C2321] border border-[#D9D7D0]/30 hover:bg-[#EFEEE9] transition-colors"
          >
            <FileCode2 className="w-4 h-4" />
            下载可编辑源文件
          </button>
          <button
            id="btn-save-materials"
            onClick={handleSaveMaterials}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium text-[#1C2321] border border-[#D9D7D0]/30 hover:bg-[#EFEEE9] transition-colors"
          >
            <FolderPlus className="w-4 h-4" />
            保存到我的材料
          </button>
          {saveStatusVisible && (
            <span id="save-status" className="text-xs text-[#1E8E5A] inline-flex items-center gap-1">
              <Check className="w-3.5 h-3.5" />
              已保存到「我的材料」
            </span>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-x-5 gap-y-1 mt-3">
          <a
            id="link-to-interview"
            href="/interview"
            className="text-sm font-medium text-[#0E6A5F] hover:underline inline-flex items-center gap-1"
          >
            去模拟面试，用这份简历被追问
            <ArrowRight className="w-3.5 h-3.5" />
          </a>
          <a
            id="link-back-chat"
            href="/chat"
            className="text-sm text-[#59635E] hover:text-[#1C2321] hover:underline inline-flex items-center gap-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            返回工作台
          </a>
        </div>
        <p className="text-xs text-[#59635E] mt-3 flex flex-wrap items-center gap-x-1.5">
          <ShieldX className="w-3.5 h-3.5 text-[#1E8E5A]" />
          当前：一页版 · 内容均已绑定来源或标注待确认 · 知识库版本：免费版 v2.3.0
        </p>
      </section>
    </main>
  );
}
