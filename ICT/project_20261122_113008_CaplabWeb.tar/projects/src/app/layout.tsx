import type { Metadata } from 'next';
import './globals.css';
import { SiteHeader } from '@/components/site-header';

export const metadata: Metadata = {
  title: {
    default: 'CapLab - AI 生涯路径收敛平台',
    template: '%s | CapLab',
  },
  description:
    '面向大学生的 AI 生涯路径收敛平台。不替你做终身决定，而是用低成本现实行动验证选择。',
  keywords: ['CapLab', '生涯规划', '大学生', '路径收敛', '证据化决策'],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="min-h-screen bg-background text-foreground font-sans antialiased">
        <SiteHeader />
        {children}
      </body>
    </html>
  );
}
