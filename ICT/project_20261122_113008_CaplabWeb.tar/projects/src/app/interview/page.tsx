'use client';

import React, { useState } from 'react';
import {
  FlaskConical,
  Mic,
  Briefcase,
  ListOrdered,
  Settings2,
  Languages,
  CircleStop,
  Pause,
  MessagesSquare,
  Bot,
  CornerDownRight,
  Sparkles,
  SendHorizontal,
  ChevronsDownUp,
  ClipboardCheck,
  FileSearch,
  Lightbulb,
  Target,
  Download,
  RotateCcw,
  PencilLine,
  LayoutDashboard,
} from 'lucide-react';

export default function InterviewPage() {
  const [answerText, setAnswerText] = useState('');

  const handleSubmitAnswer = () => {
    if (!answerText.trim()) {
      console.log('请先作答再提交');
      return;
    }
    console.log('提交 Q3 回答，等待面试引擎判定是否触发追问');
  };

  const handleVoiceInput = () => {
    console.log('需要调用语音识别接口实现语音作答');
  };

  const handlePauseInterview = () => {
    console.log('面试已暂停并延期，进度保留，不视为完成');
  };

  const handleEndInterview = () => {
    console.log('提前结束：未答题无法评估，进入 EVALUATED 反馈');
  };

  const handlePracticeAgain = () => {
    console.log('开启新一轮模拟面试');
  };

  return (
    <div className="min-h-screen bg-[#F6F5F2] text-[#1C2321] font-sans antialiased">
      {/* 导航栏 */}
      <header className="sticky top-0 z-40 h-16 bg-white/95 backdrop-blur border-b border-[#D9D7D0]/30">
        <div className="max-w-6xl mx-auto h-full px-4 sm:px-6 flex items-center justify-between gap-4">
          <a href="/home" className="flex items-center gap-2.5 shrink-0">
            <span className="w-8 h-8 rounded-lg bg-[#0E6A5F] flex items-center justify-center">
              <FlaskConical className="w-4.5 h-4.5 text-white" />
            </span>
            <span className="font-bold text-[17px] tracking-tight">CapLab</span>
          </a>
          <nav className="flex items-center gap-0.5 overflow-x-auto scrollbar-none" aria-label="主导航">
            <a href="/home" className="px-2.5 sm:px-3 py-1.5 text-[13px] font-medium text-[#59635E] hover:text-[#1C2321] hover:bg-[#EFEEE9] rounded-md transition-colors whitespace-nowrap">开场</a>
            <a href="/chat" className="px-2.5 sm:px-3 py-1.5 text-[13px] font-medium text-[#59635E] hover:text-[#1C2321] hover:bg-[#EFEEE9] rounded-md transition-colors whitespace-nowrap">对话工作台</a>
            <a href="/path-convergence" className="px-2.5 sm:px-3 py-1.5 text-[13px] font-medium text-[#59635E] hover:text-[#1C2321] hover:bg-[#EFEEE9] rounded-md transition-colors whitespace-nowrap">路径收敛</a>
            <a href="/evidence-cycle" className="px-2.5 sm:px-3 py-1.5 text-[13px] font-medium text-[#59635E] hover:text-[#1C2321] hover:bg-[#EFEEE9] rounded-md transition-colors whitespace-nowrap">证据回合</a>
            <a href="/resume" className="px-2.5 sm:px-3 py-1.5 text-[13px] font-medium text-[#59635E] hover:text-[#1C2321] hover:bg-[#EFEEE9] rounded-md transition-colors whitespace-nowrap">简历工坊</a>
            <a href="/interview" className="px-2.5 sm:px-3 py-1.5 text-[13px] font-medium bg-[#0E6A5F]/10 text-[#0E6A5F] rounded-md whitespace-nowrap" aria-current="page">模拟面试</a>
            <a href="/review-report" className="px-2.5 sm:px-3 py-1.5 text-[13px] font-medium text-[#59635E] hover:text-[#1C2321] hover:bg-[#EFEEE9] rounded-md transition-colors whitespace-nowrap">复盘报告</a>
          </nav>
        </div>
      </header>

      {/* 主内容区 */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
        {/* 页面标题 */}
        <div className="space-y-1">
          <h1 className="text-2xl font-bold tracking-tight">模拟面试间</h1>
          <p className="text-sm text-[#59635E]">基于 JD 与简历的多轮连环追问，深挖项目贡献边界，区分「教程跟做」与「独立完成」。</p>
        </div>

        {/* A. 面试配置条 */}
        <section id="interview-config-bar" className="bg-white shadow-[0_1px_3px_rgba(28,35,33,0.07),_0_1px_2px_rgba(28,35,33,0.05)] rounded-lg p-4 flex flex-wrap gap-3 items-center">
          <span className="inline-flex items-center gap-1.5 bg-[#D9ECE7] text-[#0E6A5F] rounded-full px-3 py-1 text-xs font-medium">
            <Mic className="w-3.5 h-3.5" />
            附加能力 · 模拟面试 · IN_PROGRESS
          </span>
          {/* 信息芯片-岗位 */}
          <span className="inline-flex items-center gap-1.5 bg-[#EFEEE9] text-[#59635E] rounded-full px-3 py-1 text-xs">
            <Briefcase className="w-3.5 h-3.5" />
            岗位：AI 产品经理实习生
          </span>
          {/* 信息芯片-题量 */}
          <span className="inline-flex items-center gap-1.5 bg-[#EFEEE9] text-[#59635E] rounded-full px-3 py-1 text-xs">
            <ListOrdered className="w-3.5 h-3.5" />
            题量：6 题（当前第 3 题）
          </span>
          {/* 信息芯片-模式 */}
          <span className="inline-flex items-center gap-1.5 bg-[#EFEEE9] text-[#59635E] rounded-full px-3 py-1 text-xs">
            <Settings2 className="w-3.5 h-3.5" />
            模式：标准（每题至多 1 次追问）
          </span>
          {/* 信息芯片-语言 */}
          <span className="inline-flex items-center gap-1.5 bg-[#EFEEE9] text-[#59635E] rounded-full px-3 py-1 text-xs">
            <Languages className="w-3.5 h-3.5" />
            语言：中文
          </span>
          <div className="flex items-center gap-2 ml-auto">
            <button
              id="btn-end-interview"
              onClick={handleEndInterview}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium text-[#C83E33] bg-[#C83E33]/10 hover:bg-[#C83E33]/15 active:scale-[0.98] transition-all"
            >
              <CircleStop className="w-4 h-4" />
              结束面试
            </button>
            <button
              id="btn-pause-interview"
              onClick={handlePauseInterview}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium text-[#59635E] hover:text-[#1C2321] hover:bg-[#EFEEE9] active:scale-[0.98] transition-all"
            >
              <Pause className="w-4 h-4" />
              暂停
            </button>
          </div>
          <p className="w-full text-xs text-[#59635E]">暂停不累述、不视为完成；提前结束则未答题无法评估。</p>
        </section>

        {/* B. 面试对话区 */}
        <section id="interview-chat-card" className="bg-white shadow-[0_1px_3px_rgba(28,35,33,0.07),_0_1px_2px_rgba(28,35,33,0.05)] rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-base font-semibold inline-flex items-center gap-2">
              <MessagesSquare className="w-4 h-4 text-[#0E6A5F]" />
              面试进行中 · 连环追问
            </h2>
            <span className="text-xs text-[#59635E]">一次只问一题 · 不提前提供参考答案</span>
          </div>

          <div className="space-y-4">
            {/* 回合 Q1：面试官主问题 */}
            <div className="flex items-start gap-3">
              <span className="w-9 h-9 shrink-0 rounded-full bg-[#D9ECE7] flex items-center justify-center">
                <Bot className="w-4.5 h-4.5 text-[#0E6A5F]" />
              </span>
              <div className="max-w-[85%] space-y-1">
                <span className="text-xs text-[#59635E]">面试官 · Q1 主问题</span>
                <div className="bg-[#EFEEE9] rounded-2xl rounded-tl-sm px-4 py-2.5 text-sm leading-relaxed">
                  请用 1 分钟做个自我介绍，并说明为什么想投 AI 产品实习。
                </div>
              </div>
            </div>

            {/* 回合 Q1：用户回答 */}
            <div className="flex items-start gap-3 flex-row-reverse">
              <span className="w-9 h-9 shrink-0 rounded-full bg-[#0E6A5F] text-white flex items-center justify-center text-sm font-medium">林</span>
              <div className="max-w-[85%] space-y-1 items-end flex flex-col">
                <span className="text-xs text-[#59635E]">林同学</span>
                <div className="bg-[#E7E6E0] rounded-2xl rounded-tr-sm px-4 py-2.5 text-sm leading-relaxed">
                  我是计科大三的林同学，做过校园小程序的需求整理，也访谈过产品经理校友，所以想试试产品方向。
                </div>
              </div>
            </div>

            {/* 回合 Q1：追问（由回答缺口触发） */}
            <div className="flex items-start gap-3">
              <span className="w-9 h-9 shrink-0 rounded-full bg-[#B57A0A]/15 flex items-center justify-center">
                <Bot className="w-4.5 h-4.5 text-[#B57A0A]" />
              </span>
              <div className="max-w-[85%] space-y-1">
                <span className="inline-flex items-center gap-1 rounded-full bg-[#B57A0A]/15 text-[#B57A0A] px-2 py-0.5 text-[11px] font-medium w-fit">
                  <CornerDownRight className="w-3 h-3" />
                  追问 · 由回答缺口触发
                </span>
                <div className="bg-[#B57A0A]/5 border border-[#B57A0A]/15 rounded-2xl rounded-tl-sm px-4 py-2.5 text-sm leading-relaxed">
                  你提到「想试试产品方向」——在这次投递之前，有没有哪件具体的事让你判断自己不只是好奇？
                </div>
              </div>
            </div>

            {/* 分隔线 */}
            <div className="border-t border-[#D9D7D0]/30"></div>

            {/* 回合 Q2：面试官主问题（深挖贡献边界） */}
            <div className="flex items-start gap-3">
              <span className="w-9 h-9 shrink-0 rounded-full bg-[#D9ECE7] flex items-center justify-center">
                <Bot className="w-4.5 h-4.5 text-[#0E6A5F]" />
              </span>
              <div className="max-w-[85%] space-y-1">
                <span className="text-xs text-[#59635E]">面试官 · Q2 主问题 · 贡献边界</span>
                <div className="bg-[#EFEEE9] rounded-2xl rounded-tl-sm px-4 py-2.5 text-sm leading-relaxed">
                  详细讲讲小程序项目里你具体做了什么、哪些是你独立完成的。
                </div>
              </div>
            </div>

            {/* 回合 Q2：用户回答 */}
            <div className="flex items-start gap-3 flex-row-reverse">
              <span className="w-9 h-9 shrink-0 rounded-full bg-[#0E6A5F] text-white flex items-center justify-center text-sm font-medium">林</span>
              <div className="max-w-[85%] space-y-1 items-end flex flex-col">
                <span className="text-xs text-[#59635E]">林同学</span>
                <div className="bg-[#E7E6E0] rounded-2xl rounded-tr-sm px-4 py-2.5 text-sm leading-relaxed">
                  我访谈了 12 个同学，整理了需求，画了几个页面；后端接口和小程序上线是两个学长做的。
                </div>
              </div>
            </div>

            {/* 回合 Q2：关键追问 */}
            <div className="flex items-start gap-3">
              <span className="w-9 h-9 shrink-0 rounded-full bg-[#B57A0A]/15 flex items-center justify-center">
                <Bot className="w-4.5 h-4.5 text-[#B57A0A]" />
              </span>
              <div className="max-w-[85%] space-y-1">
                <span className="inline-flex items-center gap-1 rounded-full bg-[#B57A0A]/15 text-[#B57A0A] px-2 py-0.5 text-[11px] font-medium w-fit">
                  <CornerDownRight className="w-3 h-3" />
                  追问 · 关键缺口：独立产物
                </span>
                <div className="bg-[#B57A0A]/5 border border-[#B57A0A]/15 rounded-2xl rounded-tl-sm px-4 py-2.5 text-sm leading-relaxed">
                  如果把学长的部分拿掉，只看你自己产出的东西，哪一份产物能直接拿给别人看？它解决了谁的什么问题？
                </div>
              </div>
            </div>

            {/* 分隔线 */}
            <div className="border-t border-[#D9D7D0]/30"></div>

            {/* 回合 Q3：当前题（高亮） */}
            <div id="current-question" className="flex items-start gap-3 rounded-xl bg-[#0E6A5F]/5 border border-[#0E6A5F]/20 p-3 -m-1">
              <span className="w-9 h-9 shrink-0 rounded-full bg-[#0E6A5F] flex items-center justify-center">
                <Bot className="w-4.5 h-4.5 text-white" />
              </span>
              <div className="max-w-[85%] space-y-1">
                <span className="inline-flex items-center gap-1 rounded-full bg-[#D9ECE7] text-[#0E6A5F] px-2 py-0.5 text-[11px] font-medium w-fit">
                  <Sparkles className="w-3 h-3" />
                  当前题 · Q3 · 教程跟做 vs 独立完成
                </span>
                <div className="bg-white rounded-2xl rounded-tl-sm px-4 py-2.5 text-sm leading-relaxed border border-[#0E6A5F]/15">
                  Titanic 那个项目，请你区分一下：哪些步骤是你自己设计的，哪些是跟着教程做的？
                </div>
              </div>
            </div>
          </div>

          {/* Q3 答题输入区（等待作答） */}
          <div id="answer-input-area" className="space-y-2 border-t border-[#D9D7D0]/30 pt-4">
            <div className="relative">
              <textarea
                id="answer-textarea"
                rows={3}
                value={answerText}
                onChange={(e) => setAnswerText(e.target.value)}
                className="w-full bg-[#EFEEE9] border-none rounded-lg p-3 pr-12 text-sm text-[#1C2321] placeholder:text-[#59635E]/60 focus:outline-none focus:ring-2 focus:ring-[#0E6A5F]/30 transition-colors resize-none"
                placeholder="用语音或文字回答这一题…"
              />
              <button
                id="btn-voice-input"
                title="语音输入"
                onClick={handleVoiceInput}
                className="absolute right-3 bottom-3 w-8 h-8 rounded-full bg-[#E7E6E0] hover:bg-[#E0DFD9] flex items-center justify-center text-[#59635E] hover:text-[#0E6A5F] transition-colors"
              >
                <Mic className="w-4 h-4" />
              </button>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <button
                id="btn-submit-answer"
                onClick={handleSubmitAnswer}
                className="inline-flex items-center gap-1.5 bg-[#0E6A5F] text-white px-4 py-2 rounded-md text-sm font-medium hover:opacity-90 active:scale-[0.98] transition-all"
              >
                <SendHorizontal className="w-4 h-4" />
                提交回答
              </button>
              <span className="text-xs text-[#59635E]">一次一题，答完才会有下一题与追问。</span>
            </div>
          </div>
        </section>

        {/* 分区标题条：进行中 → 已评估 */}
        <div className="flex items-center gap-3 pt-2">
          <span className="h-px flex-1 bg-[#D9D7D0]/50"></span>
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#59635E]">
            <ChevronsDownUp className="w-3.5 h-3.5" />
            以下为面试结束（EVALUATED）后的反馈
          </span>
          <span className="h-px flex-1 bg-[#D9D7D0]/50"></span>
        </div>

        {/* C. 结束后的四维反馈报告 */}
        <section id="feedback-report-card" className="bg-white shadow-[0_1px_3px_rgba(28,35,33,0.07),_0_1px_2px_rgba(28,35,33,0.05)] rounded-xl p-6 space-y-7">
          {/* 报告标题条 */}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg bg-[#D9ECE7]/60 px-4 py-3">
            <h2 className="text-base font-semibold inline-flex items-center gap-2">
              <ClipboardCheck className="w-4 h-4 text-[#0E6A5F]" />
              面试评估报告 · EVALUATED
            </h2>
            <span className="text-xs text-[#59635E]">评分仅反馈本次表现，不是录用概率，也不是招聘方评分。</span>
          </div>

          {/* 四维评分 */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* 维度1-自我介绍 */}
            <div className="rounded-lg bg-[#EFEEE9]/60 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold">自我介绍</span>
                <span className="text-lg font-bold text-[#0E6A5F]">72</span>
              </div>
              <div className="h-2 rounded-full bg-[#E7E6E0] overflow-hidden">
                <div className="h-full rounded-full bg-[#0E6A5F]" style={{ width: '72%' }}></div>
              </div>
              <p className="text-xs text-[#1E8E5A] font-medium">优点：专业与意向清楚。</p>
              <p className="text-xs text-[#59635E] leading-relaxed">建议：开场缺少一个具体事实支撑动机，可用「访谈校友后我做了什么」。</p>
            </div>

            {/* 维度2-项目 */}
            <div className="rounded-lg bg-[#EFEEE9]/60 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold">项目</span>
                <span className="text-lg font-bold text-[#0E6A5F]">65</span>
              </div>
              <div className="h-2 rounded-full bg-[#E7E6E0] overflow-hidden">
                <div className="h-full rounded-full bg-[#0E6A5F]" style={{ width: '65%' }}></div>
              </div>
              <p className="text-xs text-[#1E8E5A] font-medium">边界诚实，能主动说明后端由学长完成（加分）。</p>
              <p className="text-xs text-[#59635E] leading-relaxed">独立产物不清晰，需准备一个可独立展示的需求/原型作品。</p>
            </div>

            {/* 维度3-技术 */}
            <div className="rounded-lg bg-[#EFEEE9]/60 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold">技术</span>
                <span className="text-lg font-bold text-[#0E6A5F]">58</span>
              </div>
              <div className="h-2 rounded-full bg-[#E7E6E0] overflow-hidden">
                <div className="h-full rounded-full bg-[#0E6A5F]" style={{ width: '58%' }}></div>
              </div>
              <p className="text-xs text-[#59635E] leading-relaxed">
                本次回答未体现对需求优先级方法（如 RICE / 用户价值排序）的使用——这只代表本次没说到，
                <span className="font-medium text-[#B57A0A]">不等于你不会</span>。
              </p>
            </div>

            {/* 维度4-表达 */}
            <div className="rounded-lg bg-[#EFEEE9]/60 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold">表达</span>
                <span className="text-lg font-bold text-[#0E6A5F]">78</span>
              </div>
              <div className="h-2 rounded-full bg-[#E7E6E0] overflow-hidden">
                <div className="h-full rounded-full bg-[#0E6A5F]" style={{ width: '78%' }}></div>
              </div>
              <p className="text-xs text-[#1E8E5A] font-medium">条理清楚、用词克制。</p>
              <p className="text-xs text-[#59635E] leading-relaxed">可练习先说结论再展开。</p>
            </div>
          </div>

          {/* 逐题证据化反馈 */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold inline-flex items-center gap-2">
              <FileSearch className="w-4 h-4 text-[#0E6A5F]" />
              逐题证据化反馈
            </h3>
            <div className="divide-y divide-[#D9D7D0]/40 rounded-lg border border-[#D9D7D0]/20">
              {/* 证据-Q1 */}
              <div className="px-4 py-3 flex flex-col sm:flex-row sm:items-start gap-1 sm:gap-3">
                <span className="shrink-0 text-xs font-semibold text-[#0E6A5F] w-16">Q1 证据</span>
                <p className="text-sm text-[#59635E] leading-relaxed">回答明确了专业（计科大三）与意向（产品方向）；但动机仅以「想试试」带过，未给出访谈校友之后的具体动作，故追问成立。</p>
              </div>
              {/* 证据-Q2 */}
              <div className="px-4 py-3 flex flex-col sm:flex-row sm:items-start gap-1 sm:gap-3">
                <span className="shrink-0 text-xs font-semibold text-[#0E6A5F] w-16">Q2 证据</span>
                <p className="text-sm text-[#59635E] leading-relaxed">主动交代「访谈 12 人、整理需求、画页面」为自身产出，并诚实说明后端接口与上线由学长完成；但需求清单/原型的具体形态与解决的问题未说清，独立产物证据不足。</p>
              </div>
              {/* 证据-Q3 */}
              <div className="px-4 py-3 flex flex-col sm:flex-row sm:items-start gap-1 sm:gap-3">
                <span className="shrink-0 text-xs font-semibold text-[#C83E33] w-16">Q3</span>
                <p className="text-sm text-[#59635E] leading-relaxed">未作答，无法评估。该题本用于区分 Titanic 项目的「教程跟做 / 独立完成」边界。</p>
              </div>
            </div>
          </div>

          {/* 回答框架 + 下一轮练习重点 */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* 回答框架小卡 */}
            <div className="rounded-lg border border-[#D9D7D0]/20 bg-[#EFEEE9]/50 p-4 space-y-3">
              <h3 className="text-sm font-semibold inline-flex items-center gap-2">
                <Lightbulb className="w-4 h-4 text-[#B57A0A]" />
                可复用回答框架
              </h3>
              <p className="text-xs text-[#59635E]">以下是可复用的表达结构，不是标准答案。</p>
              <div className="rounded-md bg-white px-3 py-2.5 text-sm leading-relaxed">
                <span className="font-medium text-[#0E6A5F]">项目题框架：</span>背景一句 → 我的独立动作 → 用的方法 → 可核验结果 → 协作边界。
              </div>
            </div>

            {/* 下一轮练习重点（最多 3 条） */}
            <div className="rounded-lg border border-[#D9D7D0]/20 bg-[#EFEEE9]/50 p-4 space-y-3">
              <h3 className="text-sm font-semibold inline-flex items-center gap-2">
                <Target className="w-4 h-4 text-[#0E6A5F]" />
                下一轮练习重点
              </h3>
              <ul className="space-y-2.5">
                {/* 练习重点1 */}
                <li className="flex items-start gap-2 text-sm text-[#59635E]">
                  <Target className="w-4 h-4 mt-0.5 text-[#0E6A5F] shrink-0" />
                  <span>准备一个能独立展示的需求拆解 / 原型，专练贡献边界题。</span>
                </li>
                {/* 练习重点2 */}
                <li className="flex items-start gap-2 text-sm text-[#59635E]">
                  <Target className="w-4 h-4 mt-0.5 text-[#0E6A5F] shrink-0" />
                  <span>自我介绍加入一个具体事件与你的动作。</span>
                </li>
                {/* 练习重点3 */}
                <li className="flex items-start gap-2 text-sm text-[#59635E]">
                  <Target className="w-4 h-4 mt-0.5 text-[#0E6A5F] shrink-0" />
                  <span>练习区分「教程跟做 / 独立完成」的诚实表述。</span>
                </li>
              </ul>
            </div>
          </div>

          {/* 底部操作 */}
          <div className="flex flex-wrap items-center gap-2 border-t border-[#D9D7D0]/30 pt-5">
            <a
              id="btn-export-report"
              href="/review-report"
              className="inline-flex items-center gap-1.5 bg-[#0E6A5F] text-white px-4 py-2 rounded-md text-sm font-medium hover:opacity-90 active:scale-[0.98] transition-all"
            >
              <Download className="w-4 h-4" />
              生成报告 / 导出（PDF）
            </a>
            <button
              id="btn-practice-again"
              onClick={handlePracticeAgain}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-[#59635E] hover:text-[#1C2321] hover:bg-[#EFEEE9] border border-[#D9D7D0]/20 transition-all"
            >
              <RotateCcw className="w-4 h-4" />
              再练一轮
            </button>
            <a
              id="btn-goto-resume"
              href="/resume"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-[#59635E] hover:text-[#1C2321] hover:bg-[#EFEEE9] border border-[#D9D7D0]/20 transition-all"
            >
              <PencilLine className="w-4 h-4" />
              去做简历修改
            </a>
            <a
              id="btn-back-chat"
              href="/chat"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-[#59635E] hover:text-[#1C2321] hover:bg-[#EFEEE9] border border-[#D9D7D0]/20 transition-all"
            >
              <LayoutDashboard className="w-4 h-4" />
              返回工作台
            </a>
          </div>

          {/* 元信息 */}
          <p className="text-xs text-[#59635E]">知识库版本：免费版 v2.3.0 · 反馈基于本次可见回答。</p>
        </section>
      </main>
    </div>
  );
}
